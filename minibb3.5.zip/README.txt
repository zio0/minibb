Hello, and Welcome to miniBB!

miniBB forum software project is at the top of our programming ideas.
We feel very happy that you have chosen this product within hundreds of others.

If you are going to install it, first of all, you need to know some miniBB requirements:

1) A web server, with PHP and mySQL installed - this program doesn't run as Windows standalone;
2) mySQL server's host, login, password, and an associated database name, which will hold the forums information;
3) A minimal knowledge of how the bulletin board works and what it is for.

Please, read the installation instructions in miniBB manual, which could be found here:

ON THE WEB: http://www.minibb.com/forums/index.php?action=manual#config1

LOCALLY: /templates/manual_eng.html

In the Manual, you will also find a lot of interesting stuff about miniBB.

miniBB is FREE, which means - if you download, install and run the basic version, you don't need to pay anything to anyone.
By the General Public License conditions, only the little copyright notice (attribution link) must be kept, identifying you as a honest and reliable customer of the Open Source World.

Despite that, if you:

- would need help in installing this forum software on your site,
- would like to make advanced customizations to this software,
- would like to make custom non-core-destructive add-ons to this software,
- would like to make your forums layout completely fitting to your website,
- would like to concatenate this forums software with an existing users database:

then, please, pay attention to our "Paid Support" section:

http://www.minibb.com/paid_support.html

Providing honest, accurate and as-quick-as-possible service regarding any miniBB customized work, are our basic principles when supporting customers.

Also feel free to visit the Live Forums support, where you could not just see how this software works in action, but also may find a lot of custom solutions and answers regarding miniBB:

http://www.minibb.com/forums/

When you will run an active live community (and we're sure, with this forum software you WILL!) - feel free to provide a reciprocal LINK to your forums, so it appears in our Showcase Section and makes Google bot more happy with your project:

http://www.minibb.com/sites.html

And if you are proud of your graphical integration, just drop as a note about this, so we mention it in our virtual miniBB Gallery:

http://www.minibb.com/gallery.html

Thank you for choosing miniBB!
We hope you'll start each morning with a smile :-)

//miniBB Team