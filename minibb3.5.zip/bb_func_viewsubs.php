<?php
/*
This file is part of miniBB. miniBB is free discussion forums/message board software, supplied with no warranties.
See COPYING file for more details.
Copyright (C) 2021 Paul Puzyrev. www.minibb.com
Latest File Update: 2021-02-26
*/
if (!defined('INCLUDED776')) die ('Fatal error.');

if(isset($_POST['step'])) $step=$_POST['step']; elseif(isset($_GET['step'])) $step=$_GET['step']; else $step='';

$title.=$l_subscriptions;
$listSubs='';

if($topic>0){

if($tt=db_simpleSelect(0, $Tt, 'topic_title, forum_id', 'topic_id', '=', $topic)){

$topicTitle=$tt[0];
$forum=$tt[1];

//check moderator
if(isset($mods[$forum]) and is_array($mods[$forum]) and in_array($user_id, $mods[$forum])) $checkMod=TRUE; else $checkMod=FALSE;

if($logged_admin==1 or $checkMod){

$topicUrl='';
if(!isset($mod_rewrite) or !$mod_rewrite) {
$topicUrl="{$main_url}/{$indexphp}action=vthread&amp;forum=$forum&amp;topic=$topic";
}
else{
if($row=db_simpleSelect(0, $Tf, 'forum_name', 'forum_id', '=', $forum)){
$forumName=$row[0];
$topicUrl=addTopicURLPage(genTopicURL($main_url, $forum, $forumName, $topic, $topicTitle), PAGE1_OFFSET+1);
}
}


if($step=='delsubs'){

if($csrfchk=='' or $csrfchk!=$_COOKIE[$cookiename.'_csrfchk']) die('Could not proceed: possible CSRF/XSRF attack!');

$fs=0;
if(isset($_POST['selsub']) and sizeof($_POST['selsub'])>0){
$selsubs=array();
foreach($_POST['selsub'] as $sb) {
$ssb=(int)$sb;
if($ssb>0) $selsubs[]=$ssb;
}
$xtr=getClForums($selsubs,'','','id','or','=');
$fs=db_delete($Ts,$xtr);
unset($xtr);
}
$listSubs.='['.$l_del.' '.$fs.' '.$l_rows.']'.$brtag.$brtag;
}

$subs=array();
$users=array();
if($row=db_simpleSelect(0, $Ts, 'id, user_id, active', 'topic_id', '=', $topic, 'id asc')){
do{
$subs[$row[0]]=array($row[1], $row[2]);
$users[]=$row[1];
}
while($row=db_simpleSelect(1));
}

if(sizeof($subs)>0){

$xtr=getClForums($users,'where','',$dbUserId,'or','=');
$userInfos=array();

if($row=db_simpleSelect(0, $Tu, "{$dbUserId}, {$dbUserSheme['username'][1]}, {$dbUserSheme['user_email'][1]}")){
do{
$userInfos[$row[0]]=array($row[1], $row[2]);
}
while($row=db_simpleSelect(1));
}

unset($xtr);

$listSubs.="<form action=\"{$main_url}/{$indexphp}\" method=\"post\" class=\"formStyle\" name=\"checkoutForm\"><input type=\"hidden\" name=\"action\" value=\"viewsubs\" /><input type=\"hidden\" name=\"topic\" value=\"{$topic}\" /><input type=\"hidden\" name=\"step\" value=\"delsubs\" /><input type=\"hidden\" name=\"csrfchk\" value=\"\" />";

$allowedByWatch=TRUE;
if(isset($purgeEmailSettings) and $purgeEmailSettings==1) $allowedByWatch=FALSE;
elseif($emailusers==0) $allowedByWatch=FALSE;

foreach($subs as $sKey=>$sVal){

if($sVal[1]==0) $s='<span class="warning"><b>-</b></span>'; else $s='+';
$listSubs.="<input type=\"checkbox\" name=\"selsub[]\" value=\"{$sKey}\" class=\"vmiddle\" />&nbsp;[{$s}]&nbsp;<span class=\"txtNr\"><a href=\"{$main_url}/{$indexphp}action=userinfo&amp;user={$sVal[0]}\" class=\"mnblnk\" target=\"_blank\">{$userInfos[$sVal[0]][0]}</a>";

if($genEmailDisable!=1 and $allowedByWatch){
$listSubs.=" (<a href=\"mailto:{$userInfos[$sVal[0]][1]}\" class=\"mnblnk\">{$userInfos[$sVal[0]][1]}</a>)";
}

$listSubs.='</span>'.$brtag;

}

$listSubs.="{$brtag}<input type=\"checkbox\" onclick=\"javascript:turnAllLayers(this.checked);\" />
<script type=\"text/javascript\">
<!--
document.write('<input type=\"button\" class=\"inputButton\" value=\"{$l_deletePost}\" onclick=\"javascript:confirmDelete();\" />');
//-->
</script>
</form>";
}

$tpltx=makeUp('main_viewsubs');
if(isset($is_mobile) and $is_mobile) $tpltx=preg_replace('#<!--desktop-->(.+?)<!--/desktop-->#is', '', $tpltx);
$tmpl=ParseTpl($tpltx);
}
else{
/* Only admins allowed */
$title=$l_forbidden;
$errorMSG=$l_accessDenied;
$tmpl=ParseTpl(makeUp('main_warning'));
}

}
else{
/* No Such Topic */
$title=$l_forbidden;
$errorMSG=$l_accessDenied;
$tmpl=ParseTpl(makeUp('main_warning'));
}

echo load_header();
echo $tmpl;
display_footer();
exit;

}
else{
header("{$rheader}{$main_url}");
exit;
}

?>