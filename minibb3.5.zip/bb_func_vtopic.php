<?php
/*
This file is part of miniBB. miniBB is free discussion forums/message board software, supplied with no warranties.
Check COPYING file for more details.
Copyright (C) 2018 Paul Puzyrev www.minibb.com
Latest File Update: 2021-03-04
*/
if (!defined('INCLUDED776')) die ('Fatal error.');

$list_topics='';
$pageNav='';
$forumsList='';

if(!isset($_GET['showSep']) or $_GET['showSep']==2){
$st=1; $frm=$forum;
include ($pathToFiles.'bb_func_forums.php');
}

if (!isset($forumsArray[$forum])) {
//header($proto.' 404 Not Found');
//header('Status: 404 Not Found');
header($proto.' 410 Gone');
$errorMSG=$l_forumnotexists; $correctErr=$backErrorLink;
$title=$title.$l_forumnotexists;
$metaRobots='NOINDEX,NOFOLLOW';
echo load_header(); echo ParseTpl(makeUp('main_warning')); return;
}

$forumName=$forumsArray[$forum][0]; $forumIcon=$forumsArray[$forum][1]; $forum_desc=$forumsArray[$forum][2];
$description=substr_unicode(strip_tags($forum_desc),0,400);

if($user_sort=='') $user_sort=$sortingTopics; /* Sort messages default by last answer (0) desc OR 1 - by last new topics */

/* Redirect to the proper URL if needed */
if((!isset($_GET['showSep']) or $_GET['showSep']==2) and $user_sort==0 and !isset($_GET['sortBy'])){
$requestUrl=parseRequestForumURL($main_url);
if(isset($mod_rewrite) and $mod_rewrite) $origUrl=addForumURLPage(genForumURL($main_url, $forum, $forumName), $page);
else $origUrl=addGenURLPage("{$main_url}/{$indexphp}action=vtopic&forum={$forum}", $page, '&');

if($requestUrl!=$origUrl){
header($proto.' 301 Moved Permanently');
if(isset($metaLocation)) { $meta_relocate="{$origUrl}"; echo ParseTpl(makeUp($metaLocation));  }
else{ header("{$rheader}{$origUrl}"); }
exit;
}
}
/* --Redirect... */

$warn='';
if(!isset($_GET['showSep']) or $_GET['showSep']==2){

$numRows=$forumsArray[$forum][3];

if($numRows==0){
$errorMSG=$l_noTopicsInForum; $correctErr='';
$title=$title.$l_noTopicsInForum;
$warn=ParseTpl(makeUp('main_warning'));
}

else{

//if at least one topic exists in this forum

if(isset($mod_rewrite) and $mod_rewrite and ($user_sort==0 or (isset($ini_sort) and $user_sort==$ini_sort)) and !isset($_GET['sortBy'])) {
$urlp=genForumURL($main_url, $forum, $forumName);
$urlType='Forum';
}
else {
if($user_sort==0 and !isset($_GET['sortBy'])) $sburl=''; else $sburl="&amp;sortBy={$user_sort}";
$urlp="{$main_url}/{$indexphp}action=vtopic&amp;forum=$forum{$sburl}";
$urlType='Gen';
}

//avoiding duplicated content issues
$totalPages=ceil($numRows/$viewmaxtopic);

if($page<PAGE1_OFFSET+1) {
$realPage=PAGE1_OFFSET+1;

if(isset($mod_rewrite) and $mod_rewrite and $sortBy==0) $urlp=addForumURLPage(genForumURL($main_url, $forum, $forumName), $realPage);
else $urlp="{$main_url}/{$indexphp}action=vtopic&forum=$forum&page={$realPage}";

header($proto.' 301 Moved Permanently');

if(isset($metaLocation)) {
$meta_relocate="{$urlp}"; echo ParseTpl(makeUp($metaLocation));
}
else{
header("{$rheader}{$urlp}");
}
exit;
}

elseif($page-PAGE1_OFFSET>$totalPages) {
header($proto.' 404 Not Found');
header('Status: 404 Not Found');
$metaRobots='NOINDEX,NOFOLLOW';

if(isset($mod_rewrite) and $mod_rewrite and $sortBy==0) {
$urlpFirst=addForumURLPage(genForumURL($main_url, $forum, $forumName), PAGE1_OFFSET+1);
$urlpLast=addForumURLPage(genForumURL($main_url, $forum, $forumName), $totalPages);
}
else {
$urlpFirst="{$main_url}/{$indexphp}action=vtopic&amp;forum=$forum&amp;page=".(PAGE1_OFFSET+1);
$urlpLast="{$main_url}/{$indexphp}action=vtopic&amp;forum=$forum&amp;page={$totalPages}";
}

$errorMSG=$l_accessDenied;
if(!isset($l_pageNotFoundLinked)) $correctErr=''; else $correctErr=str_replace(array('{PAGE_NUMBER}', '{FIRST_PAGE_LINK}', '{LAST_PAGE_LINK}'), array($page, $urlpFirst, $urlpLast), $l_pageNotFoundLinked);
$title=$l_forbidden;
echo load_header();
echo ParseTpl(makeUp('main_warning'));
display_footer();
exit;
}

$pageNav=pageNav($page,$numRows,$urlp,$viewmaxtopic,FALSE,$urlType);

if($pageNav!='') $mbpn='mb';

$makeLim=makeLim($page,$numRows,$viewmaxtopic);

if(isset($customTopicSort) and is_array($customTopicSort) and isset($customTopicSort[$forum])) 
$defaultSorting="{$brtag}<a href=\"{$main_url}/{$indexphp}action=vtopic&amp;forum={$forum}&amp;sortBy=2\" class=\"mnblnk\">{$l_sortBy}&nbsp;{$customTopicSort[$forum][1]}</a>";

if( (!isset($_GET['sortBy']) or $sortBy==2) and isset($customTopicSort) and is_array($customTopicSort) and isset($customTopicSort[$forum])) { $orderBy=$customTopicSort[$forum][0];
$sortedByT=$customTopicSort[$forum][1];
$defaultSorting='';
}
elseif ($user_sort==1) $orderBy='sticky DESC,topic_id DESC';
else $orderBy='sticky DESC,topic_last_post_id DESC';

$colls=array();

if($cols=db_simpleSelect(0,$Tt,'topic_id, topic_title, topic_poster, topic_poster_name, topic_time, topic_status, posts_count, sticky, topic_views, topic_last_post_id, topic_last_post_time, topic_last_poster','forum_id','=',$forum,$orderBy,$makeLim)) {
do {
if(!isset($textLd)) $lPosts[]=$cols[9];
else { if($user_sort==0) $lPosts[]=$cols[9]; else $lPosts[]=$cols[0]; }
$colls[]=array($cols[0], $cols[1], $cols[2], $cols[3], $cols[4], $cols[5], $cols[6], $cols[7], $cols[8], $cols[9], $cols[10], $cols[11]);
}
while($cols=db_simpleSelect(1));
}

if(isset($textLd)){

if(sizeof($lPosts)>0) {
if($user_sort==0) { $ordb='post_id'; $ordSql='DESC'; } else { $ordb='topic_id'; $ordSql='ASC'; }
$xtr=getClForums($lPosts,'where','',$ordb,'or','=');
}
else $xtr='';

if($xtr!=''){
if($row=db_simpleSelect(0, $Tp, 'poster_id, poster_name, post_time, topic_id, post_text, post_id', '', '', '', 'post_id '.$ordSql))
do
if(!isset($pVals[$row[3]])) $pVals[$row[3]]=array($row[0],$row[1],$row[2],$row[4],$row[5]); else continue;
while($row=db_simpleSelect(1));
unset($xtr);
}
}

if(!isset($disableSuperSticky)) require($pathToFiles.'bb_func_supersticky.php');
else $specialThreadsArr=array();

$i=1;
$tpl=makeUp('main_topics_cell');

foreach($colls as $cols){

$topic=$cols[0];
if(!in_array($topic, $specialThreadsArr)){

if($i>0) $bg='tbCel1';else $bg='tbCel2';
$topic_reverse='';
$topic_views=$cols[8];
$lm=$cols[9];
if(isset($themeDesc) and in_array($topic,$themeDesc)) $topic_reverse="<img src=\"{$main_url}/img/topic_reverse.gif\" class=\"authorIcon\" alt=\"\" />&nbsp;";

$topicTitle=$cols[1];

if(trim($topicTitle)=='') $topicTitle=$l_emptyTopic;
if(isset($_GET['h']) and $_GET['h']==$topic) $topicTitle='&raquo; '.$topicTitle;

$numReplies=$cols[6]; if($numReplies>=1) $numReplies-=1;
if ($cols[3]=='') $cols[3]=$l_anonymous; $topicAuthor=$cols[3];
$whenPosted=convert_date($cols[4]);

if(!isset($lastPosterIcon)) $lastPosterIcon="<img src=\"{$main_url}/img/s.png\" class=\"authorIcon\" alt=\"{$l_lastAuthor}\" title=\"{$l_lastAuthor}\" />&nbsp;";

if(isset($pVals[$topic][0])) $lastPosterID=$pVals[$topic][0]; else $lastPosterID='N/A';

if($numReplies>0 and isset($cols[11]) and $cols[11]!='') $lastPoster=$lastPosterIcon.$cols[11];
elseif($numReplies>0 and isset($pVals[$topic][1])) $lastPoster=$lastPosterIcon.$pVals[$topic][1];
else $lastPoster='&mdash;';

if($numReplies>0 and isset($cols[10])) $lastPostDate=convert_date($cols[10]);
elseif($numReplies>0 and isset($pVals[$topic][2])) $lastPostDate=convert_date($pVals[$topic][2]);
else $lastPostDate='';

if(isset($textLd) and isset($pVals[$topic][3])){
$lptxt=($textLd==1?$pVals[$topic][3]:strip_tags(str_replace(array('<br />', '<br>'), ' ', $pVals[$topic][3])));
$lastPostText=$lptxt;
}

//Link to latest post in topic
if(isset($themeDesc) and in_array($topic, $themeDesc)) $vvpn=TRUE; else $vvpn=FALSE;
if($numReplies<$viewmaxreplys or $vvpn) $pagelm=PAGE1_OFFSET+1; else $pagelm=ceil(($numReplies+1)/$viewmaxreplys)+PAGE1_OFFSET;

if(isset($mod_rewrite) and $mod_rewrite) {
$urlp=genTopicURL($main_url, $forum, $forumName, $topic, $topicTitle);
$urlType='Topic';
$lmurl1=addTopicURLPage($urlp, $pagelm)."#msg{$lm}";
}
else {
$urlp="{$main_url}/{$indexphp}action=vthread&amp;forum=$forum&amp;topic=$topic";
$urlType='Gen';
$lmurl1="{$main_url}/{$indexphp}action=vthread&amp;forum={$forum}&amp;topic={$topic}&amp;page={$pagelm}#msg{$lm}";
}

$pageNavCell='';
if($numReplies>0) {

if($numReplies>$viewmaxreplys){
if(!(isset($is_mobile) and $is_mobile)){
$pageNavCell=pageNav(PAGE1_OFFSET+1,$numReplies+1,$urlp,$viewmaxreplys,TRUE,$urlType);
}
else{
if(!isset($l_mobilePages)) $l_mobilePages='Pages';
$totalPages=ceil($numReplies/$viewmaxreplys);
$pageNavCell='&nbsp;&nbsp;<span class="txtSm pages noWrap"><img src="'.$main_url.'/img/page.gif" alt="'.$l_mobilePages.'" title="'.$l_mobilePages.'" />&nbsp;<b>'.$totalPages.'</b></span>';
}
}

$LinkToLastPostInTopic='<a href="'.$lmurl1.'" class="mnblnk">'.$lastPostIcon.'</a>';
}
else {
$LinkToLastPostInTopic='';
}

if ($cols[7]==1 and $cols[5]==1) $tpcIcon='stlock';
elseif ($cols[7]==1) $tpcIcon='sticky';
elseif ($cols[5]==1) $tpcIcon='locked';
elseif ($numReplies<=0) $tpcIcon='empty';
elseif ($numReplies>=$viewmaxreplys) $tpcIcon='hot';
else $tpcIcon='default';

$topicIcon="<img src=\"{$main_url}/img/topic_{$tpcIcon}.gif\" alt=\"{$topicTitle}\" title=\"{$topicTitle}\" class=\"forumIcon\" />";

if(isset($mod_rewrite) and $mod_rewrite) {
$linkToTopic=addTopicURLPage(genTopicURL($main_url, $forum, $forumName, $topic, $topicTitle), PAGE1_OFFSET+1);
}
else $linkToTopic="{$main_url}/{$indexphp}action=vthread&amp;forum={$forum}&amp;topic={$topic}";

if(function_exists('parseTopic')) parseTopic();

$numRepliesClean=parseNumClean($numReplies);
$topic_viewsClean=parseNumClean($topic_views);

$numReplies=parseStatsNum($numReplies);
$topic_views=parseStatsNum($topic_views);

$list_topics.=ParseTpl($tpl);
$i=-$i;
}
}
}//request ok

$newTopicLink='<a href="'.$main_url.'/'.$indexphp.'action=vtopic&amp;forum='.$forum.'&amp;showSep=1"  class="mnblnk">'.$l_new_topic.'</a>';
}//if not showsep

$l_messageABC=$l_message;

$emailCheckBox=emailCheckBox();

//dynamic BB buttons
$mpf=ParseTpl(makeUp('main_post_form'));
$mpfs=convertBBJS($mpf);
if($mpfs!='') $mainPostForm=$mpfs; else $mainPostForm=$mpf;

if($page>PAGE1_OFFSET+1) {
$tpage=' - '.$l_page.' '.($page-PAGE1_OFFSET);
$description.=' ('.$l_page.' '.($page-PAGE1_OFFSET).')';
}
else $tpage='';
$title1=$title; $title=$forumName;
$title.=$tpage;
if(isset($addMainTitle)) $title.=' - '.str_replace(' - ','',$title1);


if(!isset($_GET['showSep']) or (isset($numRows) and $numRows==0)) {
$main=makeUp('main_topics');
if($pageNav=='') $main=preg_replace("#<!--pageNav-->(.*?)<!--/pageNav-->#is", '', $main);
if(isset($_GET['showSep'])) $main=preg_replace("#<!--MAINTOPICFORM-->(.*?)<!--/MAINTOPICFORM-->#is", '', $main);
}
else {
$main='';
}

$nTop=1;
$allowForm=(!defined('ARCHIVE') and ($user_id==1 or $isMod==1));
$c1=(in_array($forum,$clForums) and isset($clForumsUsers[$forum]) and !in_array($user_id,$clForumsUsers[$forum]) and !$allowForm);
$c3=(isset($poForums) and in_array($forum, $poForums) and !$allowForm);
$c4=(isset($roForums) and in_array($forum, $roForums) and !$allowForm);

if ($c1 or $c3 or $c4) {
if($main!='') $main=preg_replace("/(<form.*<\/form>)/Uis", '', $main);
$nTop=0;
$newTopicLink='';
$startNewTopicLink='';
}

if(!isset($_GET['showSep']) and $numRows<5) { $startNewTopicLink=''; $nTop=0; }

if($user_id==0) $l_sub_post_tpc=$l_enterforums.'/'.$l_sub_post_tpc;
$topic=0;
echo load_header();
if(!isset($startNewTopicLink) and isset($l_menu[7])) $startNewTopicLink=trim(str_replace($l_sepr, '', $l_menu[7]));
echo $warn;
if($main!='') echo ParseTpl($main);
?>