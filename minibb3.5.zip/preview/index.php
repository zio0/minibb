<?php
define ('INCLUDED776',1);
include('../setup_options.php');
if(!isset($brtag)) $brtag='<br />';
if(isset($pathToFiles) and $pathToFiles=='./') $pathToFiles='../';
include($pathToFiles.'lang/'.$lang.'.php');
if(!isset($l_preview)) $l_preview='Preview';
if(isset($_POST['html'])) $html=TRUE; else $html=FALSE;
?>
<!doctype html>
<head>
<title><?php echo $l_preview; ?></title>
<?php echo $l_meta; ?>
<script type="text/javascript">
<!--
function submitForm(){
var prevForm, idForm, vall, input, el, nmf, i;

idForm=window.opener.document.forms['postMsg'];

prevForm = document.createElement('form');
prevForm.setAttribute('method', 'POST');
prevForm.setAttribute('action', '<?php echo $main_url; ?>/<?php echo $indexphp; ?>');
prevForm.setAttribute('style', 'display:none');

input = document.createElement('input');
input.setAttribute('type', 'hidden');
input.setAttribute('name', 'postText');
input.setAttribute('value', idForm.elements['postText'].value);

prevForm.appendChild(input);

if(idForm.elements['topicTitle']) {

input = document.createElement('input');
input.setAttribute('type', 'hidden');
input.setAttribute('name', 'topicTitle');
input.setAttribute('value', idForm.elements['topicTitle'].value);

prevForm.appendChild(input);

}

<?php
if($html){
?>
input = document.createElement('input');
input.setAttribute('type', 'hidden');
input.setAttribute('name', 'html');
input.setAttribute('value', '1');

prevForm.appendChild(input);
<?php
}
?>

input = document.createElement('input');
input.setAttribute('type', 'hidden');
input.setAttribute('name', 'prevForm');
input.setAttribute('value', '1');

prevForm.appendChild(input);

nmf=0;
el = idForm.elements;
for(i = 0; i < el.length; i++) {
vall=el[i].name.substring(0,8);
if(vall=='userfile' && el[i].value.trim()!='') nmf++;
}
if(nmf>0){
input = document.createElement('input');
input.setAttribute('type', 'hidden');
input.setAttribute('name', 'numFiles');
input.setAttribute('value', nmf);

prevForm.appendChild(input);
}

document.body.innerHTML = prevForm.outerHTML;
document.forms[0].submit();
}
//-->
</script>
</head>
<body onload="javascript:submitForm();">
<div style="width:100%;display:block;text-align:center"><img src="<?php echo $main_url; ?>/img/progress.gif" alt="" title="" /></div>
</body>
</html>