<?php
/*
Message preview script for miniBB.
This file is part of miniBB. miniBB is a free discussion forums/message board software, supplied with no warranties.
Check the COPYING file for more details.
Copyright (C) 2018 Paul Puzyrev. www.minibb.com
Latest File Update: 2021-03-16
*/
if (!defined('INCLUDED776')) die ('Fatal error.');

if(isset($_POST['action']) and $_POST['action']=='pmail') $post_text_minlength=1;

$tpl=makeUp('main_preview');

$topicTitle2='';

$isEmptyField=FALSE;

if(isset($_POST['topicTitle']) and strlen_unicode(trim($_POST['topicTitle']))<$post_text_minlength) {
$postText2='<span class="warning">'.$l_enterSubject.'</span>';
$isEmptyField=TRUE;
}

if(!$isEmptyField){
if(isset($_POST['postText']) and strlen_unicode(trim($_POST['postText']))<$post_text_minlength){
$postText2='<span class="warning">'.$l_enterMessage.'</span>';
$isEmptyField=TRUE;
}
}

if($isEmptyField){
$tpl=preg_replace("#<!--num_files-->(.+?)<!--/num_files-->#s",'',$tpl);
}
else{

if(!function_exists('textFilter')) require($pathToFiles.'bb_func_txt.php');

$logged_admin=($user_id==1?1:0);

$disbbcode=(isset($_POST['disbbcode']) and $_POST['disbbcode']=='on'?1:0);

if(!(isset($_POST['html']) and (int)$_POST['html']==1)) {
if(isset($_POST['topicTitle'])) $topicTitle2=stripslashes(textFilter($_POST['topicTitle'],$topic_max_length,$post_word_maxlength,0,1,0,0));
$postText2=stripslashes(textFilter($_POST['postText'],$post_text_maxlength,$post_word_maxlength,1,$disbbcode,1,$logged_admin));
}
else{
$postText2=operate_string($_POST['postText'], TRUE);
}

if(!(isset($_POST['numFiles']) and (int)$_POST['numFiles']>0)) $tpl=preg_replace("#<!--num_files-->(.+?)<!--/num_files-->#s",'',$tpl);

}

if($topicTitle2=='') $tpl=preg_replace("#<!--topic_title-->(.+?)<!--/topic_title-->#s",'',$tpl);

echo ParseTpl($tpl);
exit;

?>