<?php
/*
This file is part of miniBB. miniBB is free discussion forums/message board software, supplied with no warranties.
Check COPYING file for more details.
Copyright (C) 2011 Paul Puzyrev. www.minibb.com
Latest File Update: 2021-01-18
*/
if (!defined('INCLUDED776')) die ('Fatal error.');

$usrid=(isset($_GET['usrid'])?(int)$_GET['usrid']+0:0);

$allowUnsub=FALSE;
$chkCode=FALSE;

if(isset($_GET['code']) and preg_match("#^[a-zA-Z0-9]+$#", $_GET['code'])){
//trying to unsubscribe directly from email
$chkField='email_code';
$chkVal=$_GET['code'];
$userCondition=TRUE;
$chkCode=TRUE;
}
else{
//manual unsubsribe
$chkField='user_id';
$chkVal=$user_id;
$userCondition=($usrid==$user_id);
}

if ($topic!=0 and $usrid>0 and $userCondition and $ids=db_simpleSelect(0, $Ts, 'id, user_id', 'topic_id', '=', $topic, '', '', $chkField, '=', $chkVal)) {

$finalAllow=( ($chkCode and $ids[1]==$usrid) OR (!$chkCode and $user_id==$usrid) );

$op=0;
if($finalAllow) $op=db_delete($Ts,'id','=',$ids[0]);

if ($op>0) {
$errorMSG=$l_completed; $title.=$l_completed;

$topicUrl='';

if($row=db_simpleSelect(0, $Tt, 'forum_id, topic_title', 'topic_id', '=', $topic)){
$forum=$row[0];
$topicTitle=$row[1];
if(!isset($mod_rewrite) or !$mod_rewrite) {
$topicUrl="{$main_url}/{$indexphp}action=vthread&amp;forum=$forum&amp;topic=$topic";
}
else{
if($row=db_simpleSelect(0, $Tf, 'forum_name', 'forum_id', '=', $forum)){
$forumName=$row[0];
$topicUrl=addTopicURLPage(genTopicURL($main_url, $forum, $forumName, $topic, $topicTitle), PAGE1_OFFSET+1);
}
}
}

if($topicUrl!=''){
$correctErr="<a href=\"{$topicUrl}\" class=\"mnblnk\">{$l_back}</a>";
}

}

else {
$title.=$l_itseemserror; $errorMSG=$l_itseemserror;
}

}
else {
$title.=$l_forbidden; $errorMSG=$l_accessDenied;
}

echo load_header(); echo ParseTpl(makeUp('main_warning')); return;
?>