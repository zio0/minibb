<?php
/*
The functionality to log and block brute-forced login attempts - admin panel.
This file is part of miniBB. miniBB is a free discussion forums/message board software, supplied with no warranties.
Check COPYING file for more details.
Copyright (C) 2020 Paul Puzyrev. www.minibb.com
Latest File Update: 2021-05-13
*/

if (!defined('INCLUDED776')) die ('Fatal error.');

$tpl='';
$tplTitle='';
$title=$l_flaAdminList;

if($logged_admin==1 or $isMod==1){

if(isset($_GET['step'])) $step=$_GET['step']; elseif(isset($_POST['step'])) $step=$_POST['step']; else $step='';

//clean-up expired records
$delres=db_delete($GLOBALS['Tl'], 'blocked_until', '<', "'".date('Y-m-d H:i:s')."'");
if($delres>0){
addToLog($fla_logFile, $fla_logLang['delete'].' '.$delres);
}

if((int)$step==2 and $logged_admin==1){

$f=fopen($fla_logFile, 'w');
fclose($f);
$step=1;

}

if((int)$step==0){

$title=$l_flaAdminListCurrent;

define('DISABLE_CONVERT_DATE_BACK', 1);

$tplTitle=<<<out
<table class="tbTransparentmb"><tr><td><h1 class="headingTitle">{$l_flaAdminList} &mdash; {$l_flaAdminListCurrent}</h1></td></tr></table>
out;

$allowedViewIp=FALSE;
if($logged_admin==1) $allowedViewIp=TRUE;
else{
if(isset($modsLimited) and is_array($modsLimited) and sizeof($modsLimited)>0 and isset($modsLimited['allowed_viewip']) and is_array($modsLimited['allowed_viewip']) and sizeof($modsLimited['allowed_viewip'])>0){
if(in_array($user_id, $modsLimited['allowed_viewip'])) $allowedViewIp=TRUE;
}
}

if($row=db_simpleSelect(0, $Tl, 'forced_id, forced_username, forced_ip, forced_amount, blocked_until', '', '', '', 'blocked_until asc')){

do{

$b_until=convert_date($row[4]);

if(isset($is_mobile) and $is_mobile){

$tpl.="<table class=\"forumsmb\">
<tr><td class=\"tbClCp\">{$l_sub_name}</td><td class=\"caption5\"><a href=\"{$main_url}/{$indexphp}action=userinfo&amp;user={$row[0]}\" target=\"_blank\" class=\"mnblnk\">{$row[1]}</a></td></tr>";
if($allowedViewIp) $tpl.="<tr><td class=\"tbClCp\">{$l_flaAdminListIP}</td><td class=\"caption5\">{$row[2]}</td></tr>";
$tpl.="<tr><td class=\"tbClCp\">{$l_flaAdminListAttempts}</td><td class=\"caption5\">{$row[3]}</td></tr>
<tr><td class=\"tbClCp\">{$l_flaAdminListDate}</td><td class=\"caption5\">{$b_until}</td></tr>
</table>";

}
else{

$tpl.="<tr><td class=\"caption5\"><a href=\"{$main_url}/{$indexphp}action=userinfo&amp;user={$row[0]}\" target=\"_blank\" class=\"mnblnk\">{$row[1]}</a></td>";
if($allowedViewIp) $tpl.="<td class=\"caption5\">{$row[2]}</td>";
$tpl.="<td class=\"caption5\">{$row[3]}</td><td class=\"caption5\">{$b_until}</td></tr>";

}

}
while($row=db_simpleSelect(1));

if(!(isset($is_mobile) and $is_mobile)){

$tpl="<table class=\"forumsmb\"><tr><td class=\"tbClCp\">{$l_sub_name}</td>".($allowedViewIp?"<td class=\"tbClCp\">{$l_flaAdminListIP}</td>":'')."<td class=\"tbClCp\">{$l_flaAdminListAttempts}</td><td class=\"tbClCp\">{$l_flaAdminListDate}</td></tr>".$tpl.'</table>';

}

}

}
elseif((int)$step==1 and $logged_admin==1){

$title=$l_flaAdminListLogFile;

$tplTitle=<<<out
<table class="tbTransparentmb"><tr><td><h1 class="headingTitle">{$l_flaAdminList} &mdash; {$l_flaAdminListLogFile}</h1></td></tr></table>
out;

if(file_exists($fla_logFile) and filesize($fla_logFile)>0){

$tpl='<table class="forumsmb"><tr><td class="tbTransparentCell">'.str_replace(array("\r\n"), array('<br />'), file_get_contents($fla_logFile)).'</td></tr></table>';

if($logged_admin==1){
$tpl.=<<<out
<table class="forumsmb"><tr><td class="tbTransparentCell"><a href="{$main_url}/{$indexphp}action=fla&amp;step=2" class="mnblnk">{$l_flaDeleteLog}</a></td></tr></table>
out;
}

}
else $tpl='';

}

}

echo load_header(); echo $tplTitle.$tpl; return;

?>